
// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("myBtn").style.display = "block";
    } else {
        document.getElementById("myBtn").style.display = "none";
    }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
    document.body.scrollTop = 0; // For Chrome, Safari and Opera
    document.documentElement.scrollTop = 0; // For IE and Firefox
}
$(document).ready(function() {
    // The recommended way from within the init configuration:
    Dropzone.options.dropzoneUpload = {
      init: function() {
          this.on("success", function(file, responseText) {
            $("#file_full_path").val(responseText);
              console.log(responseText);
          });
      }
    };
    $("#file_upload").hide();
    $(".loader").hide();

    $("#upload_btn").click(function(){
      $("#editor-one").empty();
      $("#editor-one").toggle("slow");
      $("#file_upload").toggle("slow");
      $(this).text(function(i, text){
          if (text === "Upload File") {
            text = "Input Text";
            $("#editor-one").empty();
          } else {
            text = "Upload File";
            $("#file_full_path").val('');
            $( ".dz-preview" ).remove();
          }
          return text;
      })
      // $("#upload_btn").text("Input Text");
    });
    $("#get_tags").click(function(){
      $(".loader").show();
      // action goes here!!
      var key_word_box = $("#key_word_box").is(":checked");
      var judgement_box = $("#judgement_box").is(":checked");
      var general_info_box = $("#general_info_box").is(":checked");
      var patent_tag_box = $("#patent_tag_box").is(":checked");
      var time_tag_box = $("#time_tag_box").is(":checked");
      var state_tag_box = $("#state_tag_box").is(":checked");
      var court_tag_box = $("#court_tag_box").is(":checked");
      var type_of_case_box = $("#type_of_case_box").is(":checked");
      var input_text = $("#editor-one").html();
      var file_full_path = $("#file_full_path").val();
      get_tags(
        key_word_box,
        judgement_box,
        general_info_box,
        type_of_case_box,
        patent_tag_box,
        time_tag_box,
        state_tag_box,
        court_tag_box,
        input_text,
        file_full_path);

    });

    $('#select_all').change(function() {
        var checkboxes = $(this).closest('form').find(':checkbox');
        if($(this).is(':checked')) {
            checkboxes.prop('checked', true);
        } else {
            checkboxes.prop('checked', false);
        }
    });
    $("#reset").click(function(){
      $("#editor-one").empty();
    });
});

function get_tags(
  key_word_box,
  judgement_box,
  general_info_box,
  type_of_case_box,
  patent_tag_box,
  time_tag_box,
  state_tag_box,
  court_tag_box,
  input_text,
  file_full_path) {
  $.ajax({
      url:'/test',
      data: {
            key_word_tag: key_word_box,
            judgement_tag: judgement_box,
            general_tag: general_info_box,
            type_of_case: type_of_case_box,
            patent_tag: patent_tag_box,
            time_tag: time_tag_box,
            state_tag: state_tag_box,
            court_tag: court_tag_box,
            input_text: input_text,
            file_full_path: file_full_path},
      type: 'POST',
      //crossDomain: true,
      dataType: 'json',
      //jsonp: false,
      success: function(response) {
        $("#output").empty();
        // response print pdf
        someJSONdata = response;
        console.log(someJSONdata);
        if (general_info_box) {
          print_tag_table("general_info", response.general_info);
        }
        if (type_of_case_box) {
          print_tag_table("type_of_case", response.type_of_case);
        }
        if (patent_tag_box) {
          print_tag_table("patent_tag", response.patent_tag);
        }
        if (time_tag_box) {
          print_tag_table("time_tag", response.time_tag);
        }
        if (state_tag_box) {
          print_tag_table("state_tag", response.state_tag);
        }
        if (court_tag_box) {
          print_tag_table("court_tag", response.court_tag);
        }
        if (judgement_box) {
          print_tag_table("judgement", response.judgement);
        }
        if (key_word_box) {
          print_tag_table("key_word", response.key_word);
        }
        $('html, body').animate({
            scrollTop: $("#output").offset().top
        }, "normal");

        $(".loader").hide();
        // alert("Success");
      },
      error: function() { alert('Failed!'); },
      // beforeSend: setHeader
  });
}

function print_tag_table(tag_type, tag_response) {
  var dict_tag = {"time_tag": "Time Tag Info Table",
                  "type_of_case": "Type Of Case",
                  "general_info": "General Info Table",
                  "patent_tag": "Patent Tag Info Table",
                  "state_tag": "State Tag Info Table",
                  "court_tag": "Court Tag Info Table",
                  "key_word": "Keyword Extraction Table",
                  "judgement": "Judgement Table",
                  }
  var table_html =
     '<div class="'+ tag_type +'_panel">' +
       '<div class="'+ tag_type +'_title">' +
        '<h2>'+ dict_tag[tag_type]+'</h2>' +
        '<div class="clearfix"></div>' +
      '</div>' +
      '<div class="'+ tag_type +'_content">' +
        '<table class="table table-hover">' +
          '<thead>' +
            '<tr>' +
              '<th>#</th>' +
              '<th>Key</th>' +
              '<th>Value</th>' +
            '</tr>' +
          '</thead>' +
          '<tbody>';

  var table_body = "";

  if (tag_response) {
    var i = 1;
    tag_response.forEach(
      function myFunction(item) {
        table_body += '<tr>' +
                '<th scope="row">'+ i +'</th>' +
                '<td>'+ Object.keys(item) +'</td>' +
                '<td>'+ item[Object.keys(item)] +'</td>' +
              '</tr>';
        i += 1;

    });
  }

  table_html += table_body +
          '</tbody>' +
        '</table>' +
      '</div>' +
    '</div>';
  var new_item = $(table_html).hide();
  // parent.append(new_item);
  $("#output").append(new_item);
  new_item.show('slow');
  var position_class = "";
  position_class = tag_type +'_panel';
  console.log(position_class);
}
