from flask import Flask, url_for, render_template, jsonify, request, redirect
from bs4 import BeautifulSoup
from bs4.element import Comment
from werkzeug.utils import secure_filename
from rake_nltk import Rake
import json
import time
import os
import re
import subprocess
#import jsonify
import urllib
app = Flask(__name__)
UPLOAD_FOLDER = '/upload'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER


@app.route("/")
def index():
    return render_template('index.html')

# get upload file
@app.route("/form_upload", methods=['POST', 'GET'])
def upload_file():
    if request.method == 'POST':
        # if get receive the request file
        file = request.files['file']
        filename = secure_filename(file.filename)
        # add time stamp to file in case upload files have name name
        if ".pdf" in filename:
            fn = 'upload/' + filename + str(time.time()) + ".pdf"
        else:
            fn = 'upload/' + filename + str(time.time())
        # save the file
        file.save(fn)
        return fn


@app.route("/test", methods=['POST', 'GET'])
def hello1():
    if request.method == 'POST':
        # if input with file
        file_name = request.form.get('file_full_path')
        if file_name:
            # if the file is PDF format
            if '.pdf' in file_name:
                # using 'PDF Box' to transfer PDF file to plain text file
                text_file = file_name.replace('.pdf', '.txt')
                subprocess.call(['java', '-jar', 'pdfbox-app-2.0.7.jar', 'ExtractText',
                                 file_name, text_file])
                file_name = text_file
            # read the file and get the content
            f = open(file_name, 'r', encoding='utf-8')
            in_text = f.read()
            f.close()
        else:
            # get the content from website's input box
            in_text = request.form.get('input_text').encode().decode('utf-8', 'ignore')
        # Post process with input content like removing html tags
        # and replace some invalid characters
        in_text = in_text.replace('', '1')
        in_text = re.sub(r'<[^<]+?>', '\n', in_text)
        in_text = re.sub(r'(\n\s*)+\n+', '\n\n', in_text)
        in_text = in_text.replace(r'&nbsp;', '')
        # call function to get state and court tags
        state_and_court = ['null', 'null']
        # if the input content is an URL link
        if re.search(r'^\n*http', in_text):
            state_and_court = get_state_court(in_text)
            # use urlopen to open the url
            in_text = in_text.replace('\n', '')
            html = urllib.request.urlopen(in_text).read()
            # call function 'text_from_html' to get the main page's content
            in_text = text_from_html(html)
            # Post process with input content like removing html tags
            # and replace some invalid characters
            in_text = in_text.replace('', '1')
            in_text = re.sub(r'<[^<]+?>', '\n', in_text)
            in_text = re.sub(r'(\n\s*)+\n+', '\n\n', in_text)
            in_text = in_text.replace(r'&nbsp;', '')
        # if the input text is longer than 5000, get first 5000 as 'part_text'
        if len(in_text) < 5000:
            part_text = in_text
        else:
            part_text = in_text[:5000]
        # initializing the tags
        patent_name = 'null'
        patent_apt = 'null'
        patent_op = 'null'
        decision_date = 'null'
        hearing = 'null'
        orders = 'null'
        case_type = 'null'
        judgement = []
        key_words = []
        key_words_extra = []
        # call functions to get the tags
        ret = ext_title(part_text)
        file_number = ext_file_num(part_text)
        if 'null' in state_and_court and ret != 'null':
            state_and_court = get_state_court(ret)
        if 'null' in state_and_court:
            state_and_court = get_state_court(in_text)
        if request.form.get('patent_tag') == 'true':
            patent_name = patent_application(part_text)
            patent_apt = patent_applicant(part_text)
            patent_op = patent_opponent(part_text)
        if request.form.get('time_tag') == 'true':
            decision_date = ext_decision_d(part_text)
            hearing = ext_hearing(part_text)
            orders = ext_orders(part_text)
        if request.form.get('type_of_case') == 'true':
            case_type = get_type_of_case(in_text, state_and_court[1])
        if request.form.get('judgement_tag') == 'true':
            judgement = get_judgement(in_text)
        if request.form.get('key_word_tag') == 'true':
            key_words = get_catch_words(in_text)
            key_words_extra = get_key_words(in_text)
        # initializing dictionaries
        ot = {}
        hd = {}
        doo = {}
        dd = {}
        ct = {}
        fn = {}
        pn = {}
        pa = {}
        po = {}
        state = {}
        court = {}
        tpc = {}
        # set the dictionaries
        hd['Hearing Date'] = hearing
        doo['Date of Orders'] = orders
        dd['Decision Date'] = decision_date
        ct['Case Title'] = ret
        fn['File Number'] = file_number
        pn['Patent Application'] = patent_name
        pa['Patent Applicant'] = patent_apt
        po['Patent Opponent'] = patent_op
        state['State'] = state_and_court[0]
        court['Court'] = state_and_court[1]
        tpc['Case Type'] = case_type
        final_judgement = []
        key_words_tag = []
        for i in range(len(judgement)):
            jug = {}
            jug['Related_Info ' + str(i + 1)] = judgement[i]
            final_judgement.append(jug)
        for i in range(len(key_words)):
            kw = {}
            kw['Catch Word ' + str(i + 1)] = key_words[i]
            key_words_tag.append(kw)
        for i in range(len(key_words_extra)):
            kwe = {}
            kwe['Key Phrase ' + str(i + 1)] = key_words_extra[i]
            key_words_tag.append(kwe)
        # turn dictionaries to jsonify format
        time_tag = []
        general_info = []
        patent_tag = []
        state_tag = []
        court_tag = []
        type_of_case = []
        if hd['Hearing Date'] != 'null':
            time_tag.append(hd)
        if doo['Date of Orders'] != 'null':
            time_tag.append(doo)
        if dd['Decision Date'] != 'null':
            time_tag.append(dd)
        if ct['Case Title'] != 'null':
            general_info.append(ct)
        if patent_name == 'null' and fn['File Number'] != 'null':
            general_info.append(fn)
        if pn['Patent Application'] != 'null':
            patent_tag.append(pn)
        if pa['Patent Applicant'] != 'null':
            patent_tag.append(pa)
        if po['Patent Opponent'] != 'null':
            patent_tag.append(po)
        if state['State'] != 'null':
            state_tag.append(state)
        if court['Court'] != 'null':
            court_tag.append(court)
        if tpc['Case Type'] != 'null':
            type_of_case.append(tpc)
        ot['court_tag'] = court_tag
        ot['state_tag'] = state_tag
        ot['patent_tag'] = patent_tag
        ot['time_tag'] = time_tag
        ot['general_info'] = general_info
        ot['type_of_case'] = type_of_case
        ot['judgement'] = final_judgement
        ot['key_word'] = key_words_tag
        # return the result in jsonify format
        return jsonify(ot)


# extract the case title
def ext_title(text):
    pattern1 = re.compile('[^<>]*?\[[0-9]{4}\][ \t]*[a-z]*.*?\(.*?\)', re.I)
    ret = re.findall(pattern1, text)
    if len(ret) == 0:
        return "null"
    return str(ret[0])


# extract the patent application
def patent_application(string):
    result = "null"
    # get the patent id
    patent_id = re.compile(r'[P|p]atent[ |\n][A|a]pplication(?:\s|\n|:)+(\d+)')
    get_id = re.findall(patent_id, string)
    # get the patent name
    patent_title = re.compile(r'Title(?:\s|\n|:)+((?:\d|\w|\n|\s|\.|-|,)*)Patent')
    get_title = re.findall(patent_title, string)
    if get_id:
        result = get_id[0]
        if get_title:
            result += " - " + get_title[0]
    return result


# extract patent opponent
def patent_opponent(string):
    # get the opponent part
    opponent = re.compile(r'Opponent(?:\s|\n|:)+((?: ?[A-Za-z\.]+[\s|,]?)+)\n')
    get_opponent = re.findall(opponent, string)
    # separate the part since there might have multiple opponents
    if len(get_opponent) > 0:
        opponent_list = []
        for i in get_opponent[0].split(','):
            i = i.strip()
            if i != "Inc." and i != 'Inc':
                opponent_list.append("@" + i)
            else:
                if len(opponent_list) != 0:
                    opponent_list[-1] += " " + i
        result = ', '.join(opponent_list)
        return result
    return "null"


# extract the patent applicant
def patent_applicant(string):
    # get patent applicant part
    applicant = re.compile(r'[P|p]atent[ |\n][A|a]pplicant(?:\s|\n|:)+((?: ?[A-Za-z\.]+[\s|,|&]?)+)\n')
    get_applicant = re.findall(applicant, string)
    # separate the part since there might have multiple applicants
    if len(get_applicant) > 0:
        applicant_list = []
        for i in get_applicant[0].split(','):
            i = i.strip()
            if 'and' or '&' in i:
                i_sub = re.split(r'and|&', i)
                for i2 in i_sub:
                    i2 = i2.strip()
                    if i2 != "" and i2 != "Inc.":
                        applicant_list.append("@" + i2)
                    elif i2 == "Inc.":
                        if len(applicant_list) != 0:
                            applicant_list[-1] += " " + i2
            else:
                if i != "Inc.":
                    applicant_list.append("@" + i)
                else:
                    if len(applicant_list) != 0:
                        applicant_list[-1] += " " + i
        result = ', '.join(applicant_list)
        return result
    return "null"


# extract the decision date
def ext_decision_d(text):
    #
    pattern3 = re.compile(r'.*?decision[^:]*?date[(]?s?[)]?(?:\s|\n|:)+([\W\D]*[0-9]*[^a-z0-9]*[a-z]*[^a-z0-9]*[0-9]*)'
                          , re.I)
    pattern4 = re.compile(r'.*?date[(]?s?[)]?[^:]*decision(?:\s|\n|:)+([\W\D]*[0-9]*[^a-z0-9]*[a-z]*[^a-z0-9]*[0-9]*)'
                          , re.I)
    final = re.findall(pattern3, text)+re.findall(pattern4, text)
    answer = final
    if not answer:
        return "null"
    return answer[0]


# extract hearing date
def ext_hearing(text):
    pattern3 = re.compile(r'hearing[^:]*?date[(]?s?[)]?(?:\s|\n|:)+([\W\D]*[0-9]*[^a-z0-9]*[a-z0-9/]*[^a-z0-9]*[0-9]*)'
                          , re.I)
    pattern4 = re.compile(r'date[(]?s?[)]?[^:]*hearing(?:\s|\n|:)+([\W\D]*[0-9]*[^a-z0-9]*[a-z0-9/]*[^a-z0-9]*[0-9]*)'
                          , re.I)
    ret = re.findall(pattern3, text)+re.findall(pattern4, text)
    if not ret:
        return "null"
    return ret[0]


# extract date of order
def ext_orders(text):
    pattern1 = re.compile(r'date of orders(?:\s|\n|:)+([\W\D]*[0-9]*[^a-z0-9]*[a-z]*[^a-z0-9]*[0-9]*)', re.I)
    ret = re.findall(pattern1, text)
    if not ret:
        return "null"
    return ret


# extract file number
def ext_file_num(text):
    pattern1 = re.compile(r'case number(?:\s|\n|:)+[\W\D]*[0-9]*/[0-9]*', re.I)
    pattern2 = re.compile(r'case number(?:\s|\n|:)+[\W\D]*[0-9]*', re.I)
    pattern3 = re.compile(r'File Number\(s\)(?:\s|\n|:)+(\d+/\d+)', re.I)
    pattern4 = re.compile(r'(?:FILE NUMBER(S)|FILE NO|FILE NO/S|FILE NUMBER)(?:\s|\n|:)+([a-zA-Z0-9 /\s]*)(?:\n)', re.I)
    ret = re.findall(pattern1, text)
    if not ret:
        ret = re.findall(pattern2, text)
    if not ret:
        ret = re.findall(pattern3, text)
    if not ret:
        ret = re.findall(pattern4, text)
    if not ret:
        return "null"
    return ret[0]


# extract state and court
def get_state_court(string, state_flag=True, court_flag=True):
    state_court = []
    state_list = {'Cth': 'Commonwealth of Australia', 'ACT': 'Australian Capital Territory',  'NSW': 'New South Wales',
                  'NT': 'Northern Territory',  'Qld': 'Queensland', 'SA': 'South Australia', 'Tas': 'Tasmania',
                  'Vic': 'Victoria',  'WA': 'Western Australia'}
    court = ""
    state = ""
    total_map = {}
    # find the state with the full name
    for s in state_list:
        get_state = re.findall(state_list[s], string, re.IGNORECASE)
        if get_state:
            total_map[state_list[s]] = len(get_state)
    if total_map:
        # set state which have top 1 occurrence
        state = max(total_map.keys(), key=(lambda k: total_map[k]))
    total_map.clear()
    # if get the state
    if state:
        state_short = ""
        for s in state_list:
            if state == state_list[s]:
                state_short = s
        # read the court list of current state
        file_open = open('state/' + state_short.lower() + '.txt')
        line = file_open.readline()
        # get each court and find the match
        while line:
            line = line.strip()
            element = line.split('~')
            if re.search(element[1], string, re.IGNORECASE):
                court = element[1]
                break
            x = re.findall(r'(?:[^A-Za-z]|^])' + element[0] + r'(?:[^A-Za-z]|$)', string)
            if len(x) != 0:
                total_map[element[1]] = len(x)
            line = file_open.readline()
        # if cannot find court
        if not total_map and not court:
            # read the court list of all the states
            file_open = open('state/total.txt')
            line = file_open.readline()
            # get each court and find the match
            # reset the state according to the matched state
            while line:
                line = line.strip()
                element = line.split('~')
                # find court's full name first
                if re.search(element[1], string, re.IGNORECASE):
                    state = state_list[element[2]]
                    court = element[1]
                    if state_flag:
                        if state:
                            state_court.append(state)
                        else:
                            state_court.append('null')
                    if court_flag:
                        if court:
                            state_court.append(court)
                        else:
                            state_court.append('null')
                    return state_court
                # find court's short name
                x = re.findall(r'(?:[^A-Za-z]|^)' + element[0] + r'(?:[^A-Za-z]|$)', string)
                if len(x) != 0:
                    total_map[element[1] + "|" + element[2]] = len(x)
                line = file_open.readline()
    else:
        # if cannot find state
        # read the court list of all the states
        file_open = open('state/total.txt')
        line = file_open.readline()
        # get each court and find the match
        # set state according to the matched court
        while line:
            line = line.strip()
            element = line.split('~')
            # find court's full name first
            if re.search(element[1], string, re.IGNORECASE):
                state = state_list[element[2]]
                court = element[1]
                if state_flag:
                    if state:
                        state_court.append(state)
                    else:
                        state_court.append('null')
                if court_flag:
                    if court:
                        state_court.append(court)
                    else:
                        state_court.append('null')
                return state_court
            # find court's short name
            x = re.findall(r'(?:[^A-Za-z]|^)' + element[0]+r'(?:[^A-Za-z]|$)', string)
            if len(x) != 0:
                total_map[element[1]+"|"+element[2]] = len(x)
            line = file_open.readline()
    if total_map:
        court_state = max(total_map.keys(), key=(lambda k: total_map[k]))
        court = court_state.split("|")[0]
        if not state:
            state = state_list[court_state.split("|")[1]]
    # set final result and return
    if state_flag:
        if state:
            state_court.append(state)
        else:
            state_court.append('null')
    if court_flag:
        if court:
            state_court.append(court)
        else:
            state_court.append('null')
    return state_court


# extract type of case
def get_type_of_case(string, court):
    # if already get court
    # read the type.txt to check if type name in the court name
    # if so, determine the type name
    if court != 'null':
        f = open('type.txt', 'r')
        t = f.readline()
        while t:
            t = t.strip()
            if t in court:
                f.close()
                return t
            t = f.readline()
    # not get type, extract 'type name Act'
    get_type = re.findall(r'((?:[A-Z][a-z|(|)]+ )+)Act ?(?:\d+)?', string)
    if get_type:
        # return the type which have top 1 occurrence
        return max(set(get_type), key=get_type.count)
    return "null"


# extract judgement
def get_judgement(text):
    r_list = []
    # get some conclusion
    get_j = re.findall(r'I conclude [^.]+.', text)
    for i in get_j:
        r_list.append(i)
    # get decision part
    get_dec = re.findall(r'DECISION((?:\s|\n|:|\w|\d|\.|,|\'|-)*)REASONS', text)
    for i in get_dec:
        if i != '':
            detail = i.split('\n')
            for j in detail:
                if len(j) > 5:
                    r_list.append(j)
    # get result part
    result = re.findall(r'(?:Conclusion|CONCLUSION|Outcome)(?:\s|\n|:)+((?:[\n|\s]?(?:.*)){1,12})', text)
    for i in result:
        if i != '':
            detail = i.split('\n')
            for j in detail:
                if len(j) > 5:
                    r_list.append(j)
    # reorganized the results as multiple sentences
    s = " ".join(r_list)
    s = re.split(r'(?!\d)\.(?!\d)', s)
    r_list.clear()
    for i in s:
        if len(i) > 10:
            r_list.append(i + '.')
    return r_list


# extract catch words
def get_catch_words(text):
    r_list = []
    # get the catchwords part
    get1 = re.findall(r'[C|c]atchwords(?:\s|\n|:)+([\w.\-–\n\s\d()’]*)', text)
    # separate the catchwords
    for i in get1:
        get2 = re.compile(r'[–|-]').split(i)
        for j in get2:
            j = j.strip().split('.')[0]
            r_list.append(j)
    return r_list


# extract key phrase
def get_key_words(text):
    # using rake to get top 13 ranked phrase
    r = Rake()
    r.extract_keywords_from_text(text)
    result = r.get_ranked_phrases()[:13]
    return result


# helper function for 'text_from_html' to check tags
def tag_visible(element):
    if element.parent.name in ['style', 'script', 'head', 'title', 'meta', '[document]']:
        return False
    if isinstance(element, Comment):
        return False
    return True


# get plain text from the html file
def text_from_html(body):
    # using beautiful soup to get page body
    soup = BeautifulSoup(body, 'html.parser')
    soup = soup.find("div", {"id": "page-main"})
    texts = soup.findAll(text=True)
    visible_texts = filter(tag_visible, texts)
    return u" ".join(t.strip() for t in visible_texts)

if __name__ == "__main__":
    app.debug = True
    app.run(host='0.0.0.0', port=8080)

